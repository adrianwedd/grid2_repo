export interface SectionProps {
  id: string;
  content: Record<string, any>;
  tone?: 'minimal' | 'bold' | 'playful' | 'corporate';
  className?: string;
}

export interface Action {
  label: string;
  href: string;
  variant?: 'primary' | 'secondary' | 'ghost' | 'link';
}