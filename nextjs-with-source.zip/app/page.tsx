import HeroSplitImageLeft from './components/HeroSplitImageLeft'

export default function Home() {
  return (
    <main>
      <HeroSplitImageLeft {...{
            content: {
                  headline: Test Export
            }
      }} />
    </main>
  )
}