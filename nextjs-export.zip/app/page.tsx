import HeroSplitImageLeft from '@/components/sections/HeroSplitImageLeft'

export default function Home() {
  return (
    <main>
      <HeroSplitImageLeft {...{
            content: {
                  headline: Test Export
            }
      }} />
    </main>
  )
}