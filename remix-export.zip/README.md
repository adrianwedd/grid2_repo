# Remix Export (Coming Soon)

Grid 2.0 will support Remix exports in a future release.

## What's Coming

- Full-stack Remix application
- Server-side rendering
- Progressive enhancement
- Nested routing
- Built-in form handling

## Alternative

For now, you can:

1. Export as Next.js and migrate manually
2. Export as static HTML for immediate deployment
3. Wait for the Remix exporter (tracking issue: #remix-export)

Built with ❤️ by Grid 2.0